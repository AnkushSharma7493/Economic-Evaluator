'use strict';

var eveluatorControllers = angular.module('evaluatorControllers', []);

eveluatorControllers
		.controller(
				'evaluatorControllers',
				[
						'$scope',
						'Properties',
						'$http',
						function($scope, Properties,$http) {
							$scope.process=function(){
								$scope.currentStep=$scope.steps[$scope.pointer];
							} 
							
							$scope.init=function(){
								$scope.evaluator=Properties.properties.steps;
								$scope.steps=[];
								
								for (var property in $scope.evaluator) {
								    if ($scope.evaluator.hasOwnProperty(property)) {
										$scope.steps.push(property);
								    }
								}
								
								/*$scope.summaryRowCount= [];
								for(var i = 0; i < Math.ceil((Object.keys($scope.evaluator).length/3).toFixed(2)); i++) {
									$scope.summaryRowCount.push("");
								}*/
								
								$scope.pointer=0;
								$scope.process();
							}
							
							$scope.init();

							$scope.back=function()
							{
								if($scope.pointer>0)
								{
									$scope.pointer--;
								}
								$scope.process();
								$scope.evaluator.EconomicEvaluator={};
							}
							
							$scope.next=function()
							{
								if($scope.pointer<$scope.steps.length-1)
								{
									$scope.pointer++;
								}
								$scope.process();
							}
							
							$scope.cancel=function()
							{
								$scope.pointer=0;
								$scope.process();
								$scope.evaluator.EconomicEvaluator={};
							}
							
							$scope.calculate=function()
							{
								var sum=0;
								var val=[];
								var label=[];
								var isFieldDisable=[];
								
								//calculate value sum
								for(var property in $scope.evaluator)
								{
									if ($scope.evaluator.hasOwnProperty(property)) {
										var temp=$scope.evaluator[property];
										
										if(temp.label!=undefined){
											for(var j=0;j<temp.label.length;j++){
												label.push(temp.label[j]);	
											}
										}
										
										if(temp.value!=undefined)
										{
											for(var i=0;i<temp.value.length;i++)
											{
												val.push(temp.value[i]);
												if(parseInt(temp.value[i])){
													sum+=parseInt(temp.value[i]);
												}
											}
										}
								    }
								 }
								
								$scope.evaluator.EconomicEvaluator={};

								// Compute labels
								$scope.evaluator.EconomicEvaluator.name="Economic Evaluation";
								
								// Compute labels
								$scope.evaluator.EconomicEvaluator.label=label;
								
								// Assign value array
								$scope.evaluator.EconomicEvaluator.value=val;
								
								// Assign Sum
								$scope.evaluator.EconomicEvaluator.sum=sum;
								
								$scope.next();
							}
							
					}]);