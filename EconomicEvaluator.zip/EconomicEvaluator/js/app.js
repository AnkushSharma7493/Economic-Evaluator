'use strict';

var EvaluatorsApp=angular.module('EvaluatorsApp', ['evaluatorControllers','designerControllers','propertyService','componentTypeService']);


EvaluatorsApp.directive('evaluatorDirective', function(){
	return {
		restrict: "E",	
		transclude : true,
		scope: { 
				data : '='
				/*link : '&'*/
				},
		templateUrl: 'partials/Directive/DynamicLayout.html'
	    }
	});