'use strict';
var docType = angular.module('propertyService', []);
docType.value('Properties',{
	properties : {
					steps : {
								Project : {
									name:"Project",
									value:[""],
									placeholder :["Provide Project Name . . ."]
								},
								Load : {
									name:"Load",
									value:[""],
									placeholder :["Provide Load . . ."]
								},
								Grid : {
									name : "Grid",
									question:"Connected to the Grid",
									answer  :false,
									label : ["Grid Power Price(Rupees/kWh)","Grid Sellback Price(Rupees/kWh)"],
									value : ["0.100","0.050"],
									placeholder :["Provide cost . . .","Provide cost . . ."]
								},
								Generator : {
									name : "Generator",
									label : ["Generator Cost (Rupees/kW)","Fuel Cost (Rupees/liter)"],
									value : [],
									placeholder :["Provide cost . . .","Provide cost . . ."]
								},
								Renewables : {
									name : "Renewables",
									question:"PV(Solar)",
									answer  :false,
									label : ["Concentrating(DC Bus)","Generic Flat Plate(AC Bus)"],
									value : [],
									placeholder :["Provide Value . . .","Provide Value . . ."]
								},
								Storage : {
									name :"Storage",
									question:"Battery",
									answer  :false,
									label : ["Generic Lead Acid","Generic Li-Ion","Generic Lead Acid(ASM)","Generic Li-Ion"],
									value : [],
									placeholder :["Provide Value . . .","Provide Value . . ."]
								},	
								Summary:{},
								EconomicEvaluator:{},
								Diagram:{}
							}
				}
});


